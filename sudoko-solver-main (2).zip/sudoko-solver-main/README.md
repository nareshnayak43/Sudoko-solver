# sudoku

  dependencies: json
                urllib3
                pygame
                
   The project is supported for python 3.
   This gives the run time view of solving sudoku illustrating back tracing algorithm by using http://www.cs.utep.edu/cheon/ws/sudoku/ api for difficulties of questions to simulate
   
steps to follow:   
   Downlaad or clone the repository to your local machine
  and run window.py on command line or prompt to launch the project

DELAY variable in sudoko.py can be increased or decreased to see the algorithm working
![alt text](https://github.com/pavan-aeturi/sudoko/blob/master/ezgif.com-video-to-gif.gif?raw=true)
